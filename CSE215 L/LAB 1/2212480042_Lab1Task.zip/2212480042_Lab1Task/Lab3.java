public class Lab3 {
    public static void main(String[] args) {
        float base = 4.5f;
        float height = 6.4f;
        float area = (float) ((1 / 2.0) * base * height);

        System.out.printf("The area is %.2f\n", area);
    }
}
