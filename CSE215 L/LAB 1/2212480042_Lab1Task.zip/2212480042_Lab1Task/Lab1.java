public class Lab1 {
    public static void main(String[] args) {
        double c = 32;
        double f = ((9 / 5.0) * c) + 32;

        System.out.println(f);
    }
}
