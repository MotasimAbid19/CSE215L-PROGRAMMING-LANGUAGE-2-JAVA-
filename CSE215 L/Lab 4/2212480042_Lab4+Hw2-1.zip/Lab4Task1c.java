package lab4;

public class Lab4Task1c {

    public static void main(String[] args) {

        System.out.println("The pattern :  ");

        for (int i = 0; i < 5; i++) 
        {
            for (int j = 0; j <=5-i ; j++) 
            {
                System.out.printf(" ");
                
            }
            for (int k = 0; k < 2*i - 1; k++) {
                System.out.printf("*");
            }
            System.out.println();
            
        }

    }

}
