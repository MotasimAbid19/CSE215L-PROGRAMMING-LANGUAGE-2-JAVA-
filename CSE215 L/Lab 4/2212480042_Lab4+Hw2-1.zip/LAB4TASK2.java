
import java.util.Scanner;

package lab4;

public class LAB4TASK2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter x and p ");
        int x = input.nextInt();
        int p = input.nextInt();
        int multipication = 1;
        for (int i = 0; i < p; i++) {
            multipication = multipication * x;
        }
        System.out.println("The value is " + multipication);

    }

}
