
package lab4;

public class Lab4Task1b {
    public static void main(String[] args) {
        
       
        System.out.println("The pattern :  ");
        
        
        
        for(int i=4 ;i>=0 ; i--)
        {
            for (int j = 0 ; j <= i; j++) {
                System.out.printf("* ");
            }
            System.out.println();
        }
        
    }
    
}
