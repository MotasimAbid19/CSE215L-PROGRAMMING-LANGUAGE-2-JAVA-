import java.util.Scanner;
package lab4;

public class Lab4Task3 {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        
        System.out.println("Enter a and b ");
        int a = input.nextInt();
        int b = input.nextInt();
        
        for(int i=a ; i<= b ; i++)
        {
            System.out.println();
            for (int j = 1 ; j <= 10; j++) 
            {
                System.out.printf("%d * %d = %d \n",j,i,(j*i));   
            }
        }
    }
    
}
