
package lab4;

import java.util.Scanner;


public class Lab4Task4b {
     public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
         System.out.println("Enter a character ");
        String s1=input.next();
        int a = s1.charAt(0);
        System.out.printf("The unicode of the 1st character is %d\n", a);
    }
 

    
}
