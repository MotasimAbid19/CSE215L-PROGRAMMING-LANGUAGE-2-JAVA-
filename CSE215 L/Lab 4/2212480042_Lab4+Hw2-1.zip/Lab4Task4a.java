
import java.util.Scanner;

package lab4;

public class Lab4Task4a {

    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Code ");
        int code=input.nextInt();
        System.out.printf("the character is %c\n",code);

    }
}
