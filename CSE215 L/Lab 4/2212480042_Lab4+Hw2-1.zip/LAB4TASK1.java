
package lab4;


public class LAB4TASK1 {
    public static void main(String[] args) {
        
       
        System.out.println("The pattern :  ");
        
        
        
        for(int i = 0 ; i<5 ; i++)
        {
            for (int j = 0 ; j <= i; j++) {
                System.out.printf("* ");
            }
            System.out.println();
        }
        
    }
    
}
